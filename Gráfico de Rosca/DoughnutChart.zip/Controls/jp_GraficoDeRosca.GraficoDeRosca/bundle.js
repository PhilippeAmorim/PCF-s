/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./GraficoRosca/index.ts":
/*!*******************************!*\
  !*** ./GraficoRosca/index.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.GraficoDeRosca = void 0;\nvar GraficoDeRosca = /** @class */function () {\n  function GraficoDeRosca() {}\n  GraficoDeRosca.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._container = container;\n    // Criação do elemento SVG\n    this._svg = document.createElementNS(\"http://www.w3.org/2000/svg\", \"svg\");\n    this._svg.setAttribute(\"viewBox\", \"0 0 100 100\");\n    this._svg.style.width = \"100%\";\n    this._svg.style.height = \"100%\";\n    // Criação do círculo de fundo (rosquinha)\n    this._backgroundCircle = document.createElementNS(\"http://www.w3.org/2000/svg\", \"circle\");\n    this._backgroundCircle.setAttribute(\"cx\", \"50\");\n    this._backgroundCircle.setAttribute(\"cy\", \"50\");\n    this._backgroundCircle.setAttribute(\"r\", \"40\"); // Raio maior que o círculo principal\n    this._backgroundCircle.setAttribute(\"fill\", \"none\"); // Cor de destaque (exemplo: #f5f5f5\")\n    this._backgroundCircle.setAttribute(\"stroke\", \"#f5f5f5\"); // Sem contorno\n    this._backgroundCircle.setAttribute(\"stroke-width\", \"10\");\n    // Criação do círculo principal\n    this._circle = document.createElementNS(\"http://www.w3.org/2000/svg\", \"circle\");\n    this._circle.setAttribute(\"cx\", \"50\");\n    this._circle.setAttribute(\"cy\", \"50\");\n    this._circle.setAttribute(\"r\", \"40\");\n    this._circle.setAttribute(\"fill\", \"none\");\n    this._circle.setAttribute(\"stroke\", \"#ddd\");\n    this._circle.setAttribute(\"stroke-width\", \"10\");\n    this._circle.setAttribute(\"stroke-dasharray\", \"251.2\");\n    this._circle.setAttribute(\"stroke-dashoffset\", \"251.2\");\n    // Criação do texto\n    this._text = document.createElementNS(\"http://www.w3.org/2000/svg\", \"text\");\n    this._text.setAttribute(\"x\", \"50\");\n    this._text.setAttribute(\"y\", \"55\");\n    this._text.setAttribute(\"text-anchor\", \"middle\");\n    this._text.setAttribute(\"font-size\", \"20px\");\n    this._text.setAttribute(\"fill\", \"#333\");\n    // Adicionar elementos SVG ao contêiner\n    this._svg.appendChild(this._backgroundCircle); // Adicionar o círculo de destaque primeiro\n    this._svg.appendChild(this._circle);\n    this._svg.appendChild(this._text);\n    this._container.appendChild(this._svg);\n  };\n  GraficoDeRosca.prototype.updateView = function (context) {\n    var valor = context.parameters.Valor.raw || 0; // Obter o valor da propriedade \"Valor\"\n    var corRosca = context.parameters.CorRosca.raw || \"#000\"; // Obter o valor da propriedade \"CorRosca\"\n    var corTexto = context.parameters.CorTexto.raw || \"#000\"; // Obter o valor da propriedade \"CorTexto\"\n    var contracor = context.parameters.ContraCor.raw || \"#f5f5f5\"; // Obter o valor da propriedade \"CorTexto\"\n    // Calcular a porcentagem com base no valor (assumindo que o valor varia de 0 a 100)\n    var porcentagem = Math.min(Math.max(valor, 0), 100);\n    // Calcular o comprimento do traço do círculo de acordo com a porcentagem\n    var comprimentoTraço = 251.2 * porcentagem / 100;\n    // Atualizar o atributo \"stroke-dashoffset\" do círculo com uma animação suave\n    this._circle.style.transition = \"stroke-dashoffset 0.3s ease-in-out\";\n    this._circle.setAttribute(\"stroke-dashoffset\", (251.2 - comprimentoTraço).toString());\n    // Atualizar a cor do círculo\n    this._circle.setAttribute(\"stroke\", corRosca);\n    // Atualizar a cor do círculo de destaque\n    this._backgroundCircle.setAttribute(\"stroke\", contracor); // Alterar a cor de destaque conforme necessário\n    // Atualizar a cor do texto\n    this._text.setAttribute(\"fill\", corTexto);\n    // Atualizar o texto exibido dentro do gráfico\n    this._text.textContent = \"\".concat(porcentagem, \"%\");\n  };\n  GraficoDeRosca.prototype.getOutputs = function () {\n    return {};\n  };\n  GraficoDeRosca.prototype.destroy = function () {};\n  return GraficoDeRosca;\n}();\nexports.GraficoDeRosca = GraficoDeRosca;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./GraficoRosca/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./GraficoRosca/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('GraficoDeRosca.GraficoDeRosca', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GraficoDeRosca);
} else {
	var GraficoDeRosca = GraficoDeRosca || {};
	GraficoDeRosca.GraficoDeRosca = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GraficoDeRosca;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}